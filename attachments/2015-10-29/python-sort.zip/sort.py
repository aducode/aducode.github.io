#!/usr/bin/python
#-*- coding:utf-8 -*-

#############################################
def bubbleSort(lst):
    '''
    冒泡排序
    '''
    for i in xrange(len(lst)-1,0,-1):
        for j in xrange(i):
            if lst[j]>lst[j+1]:
                lst[j],lst[j+1]=lst[j+1],lst[j]


############################################
def partition(lst,low,high):
    key=lst[low]
    while low<high:
        while high>low and lst[high]>key:
            high-=1
        lst[low],lst[high]=lst[high],lst[low]
        while low<high and lst[low]<key:
            low+=1
        lst[low],lst[high]=lst[high],lst[low]
    return low
def quickSort(lst,low,high):
    '''
    快速排序
    '''
    if low<high:
        mid=partition(lst,low,high)
        quickSort(lst,low,mid)
        quickSort(lst,mid+1,high)
    
#############################################
def selectSort(lst):
    '''
    选择排序
    '''
    for i in xrange(0,len(lst)-1):
        for j in xrange(i+1,len(lst)):
            if lst[j]<lst[i]:
                lst[i],lst[j]=lst[j],lst[i]


#############################################
def buildMaxHeap(lst):
    '''
    build max heap
    '''
    for end in xrange(len(lst)-1,0,-1):
        root=(end-1)/2
        while True:
            child = 2*root+1
            if child > len(lst)-1:
                break
            if child+1<=len(lst)-1 and lst[child] < lst[child+1]:
                child+=1
            if lst[root]<lst[child]:
                lst[root],lst[child] = lst[child],lst[root]
                root=child
            else:
                break

def _buildMaxHeap(lst,endIdx):
    for end in xrange(endIdx,0,-1):
        root=(end-1)/2
        while True:
            child=2*root+1
            if child>endIdx:break
            if child+1<=endIdx and lst[child]<lst[child+1]:
                child+=1
            if lst[root]<lst[child]:
                lst[root],lst[child]=lst[child],lst[root]
                root=child
            else:
                break

def myHeapSort(lst):
    _buildMaxHeap(lst,len(lst)-1)
    for i in xrange(len(lst)-1,0,-1):
        lst[i],lst[0]=lst[0],lst[i]
        _buildMaxHeap(lst,i-1)

    
def sift_down(lst,start,end):
    root=start
    while True:
        child=2*root+1
        if child > end:break
        if child+1<=end and lst[child]<lst[child+1]:
            child+=1
        if lst[root] < lst[child]:
            lst[root],lst[child]=lst[child],lst[root]
            root=child
        else:
            break

def heapSort(lst):
    '''
    堆排序
    '''
    for start in xrange((len(lst)-2)/2,-1,-1):
        sift_down(lst,start,len(lst)-1)

    for end in range(len(lst)-1,0,-1):
        lst[0],lst[end]=lst[end],lst[0]
        sift_down(lst,0,end-1)

############################################
def insertSort(lst):
    '''
    直接插入排序
    '''
    for i in xrange(1,len(lst)):
        tmp=lst[i]
        j=i-1
        while j>=0 and lst[j]>tmp:
            lst[j+1]=lst[j]
            j-=1
        lst[j+1]=tmp

###########################################
def shellSort(lst):
    '''
    希尔排序
    '''
    incrs=(5,3,2,1)
    for incr in incrs:
        '''
        增量递减5 3 1
        '''
        for n in xrange(incr):
            for i in xrange(n+incr,len(lst),incr):
                tmp=lst[i]
                j=i-incr
                while j>=0 and lst[j]>tmp:
                    lst[j+incr]=lst[j]
                    j-=incr
                lst[j+incr]=tmp

##############################################
def spli(lst):
	'''
	归并排序
	'''
    if len(lst)<=1:
        return lst
    mid=len(lst)/2
    left = spli(lst[:mid])
    right = spli(lst[mid:])
    return merge(left,right)

def merge(left,right):
    l,r=0,0
    result=[]
    while l<len(left) and r < len(right):
        if left[l]<right[r]:
            result.append(left[l])
            l+=1
        else:
            result.append(right[r])
            r+=1
    result+=right[r:]
    result+=left[l:]
    return result

if __name__=='__main__':
    lst=[200,3,5,6,10,1,2,0,100]
#    bubbleSort(lst)
#    selectSort(lst)
#    insertSort(lst)
#    shellSort(lst)
#    quickSort(lst,0,len(lst)-1)
#    heapSort(lst)
#    buildMaxHeap(lst)
#    myHeapSort(lst)
    lst=spli(lst)
    print '%s'%lst
